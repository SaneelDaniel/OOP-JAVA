import java.time.LocalDate;
import java.time.LocalTime;
import java.util.TreeSet;

public class Event  {
	
	LocalDate sDate;
	LocalDate eDate;
	LocalTime sTime;
	LocalTime eTime;
	String name;
	
	/*
	 * Constructor for Recurring Event
	 */
	public Event(String name, LocalDate sDate, LocalDate eDate, LocalTime sTime, LocalTime eTime, String days) {
		this.name = name;
		this.sDate = sDate;
		this.eDate = eDate;
		this.sTime = sTime;
		this.eTime = eTime;
	}
	
	public Event(String name, LocalDate date, LocalTime stime, LocalTime etime) {
		this.name = name;
		this.sDate = date;
		this.sTime = stime;
		this.eTime = etime;
	}
}
