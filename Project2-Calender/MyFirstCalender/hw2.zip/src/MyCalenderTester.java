
public class MyCalenderTester {
	
	public static void main(String args[]) {
		
		System.out.println("Welcome to your Calender");
		//MyCalendar cal = new MyCalendar();
		UI ui = new UI();
	}
}
